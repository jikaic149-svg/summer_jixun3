import unittest

from main import (
    DetectionSnapshot,
    RuntimeFaultGate,
    _close_resource,
    _recognition_required,
    _snapshot_detections,
)
from vision_ui import PAGE_CONTROL, PAGE_MAIN, PAGE_RESULT, VisionUiController


class CallableDetection:
    def x(self):
        return -4

    def y(self):
        return 3

    def w(self):
        return 120

    def h(self):
        return 90

    def score(self):
        return 0.8


class MainRuntimeTest(unittest.TestCase):
    def test_recognition_only_runs_on_visual_control_tasks(self):
        ui = VisionUiController()
        self.assertEqual(ui.page, PAGE_MAIN)
        self.assertFalse(_recognition_required(ui))
        ui.select_task(1)
        self.assertEqual(ui.page, PAGE_CONTROL)
        self.assertFalse(_recognition_required(ui))
        ui.select_task(2)
        self.assertTrue(_recognition_required(ui))
        ui.page = PAGE_RESULT
        self.assertFalse(_recognition_required(ui))

    def test_native_detections_are_copied_and_bounded(self):
        snapshots = _snapshot_detections(
            [CallableDetection(), CallableDetection(), CallableDetection()], 2,
        )
        self.assertEqual(len(snapshots), 2)
        self.assertIsInstance(snapshots[0], DetectionSnapshot)
        self.assertEqual(
            (snapshots[0].x, snapshots[0].y, snapshots[0].w,
             snapshots[0].h, snapshots[0].score),
            (-4, 3, 120, 90, 0.8),
        )

    def test_repeated_fault_logs_are_throttled(self):
        gate = RuntimeFaultGate(2000)
        self.assertTrue(gate.report("detect", "bad", 100))
        self.assertFalse(gate.report("detect", "bad", 200))
        self.assertTrue(gate.report("detect", "bad", 2200))
        self.assertEqual(gate.counts["detect"], 3)

    def test_resource_close_is_idempotent_at_call_site(self):
        class Resource:
            def __init__(self):
                self.closed = 0

            def close(self):
                self.closed += 1

        resource = Resource()
        _close_resource(resource)
        self.assertEqual(resource.closed, 1)


if __name__ == "__main__":
    unittest.main()
