import unittest

from vision_config import VisionConfig


class VisionConfigUdpTest(unittest.TestCase):
    def test_current_wlan_is_the_default_udp_destination(self):
        config = VisionConfig()

        self.assertEqual(config.udp_host, "192.168.237.147")
        self.assertEqual(config.telemetry_port, 5005)
        self.assertEqual(config.command_port, 5007)
        self.assertEqual(config.status_port, 5008)

    def test_udp_setting_toggles_current_wlan_and_broadcast(self):
        config = VisionConfig()

        self.assertEqual(config.adjust_setting(2, 1), "255.255.255.255")
        self.assertEqual(config.adjust_setting(2, 1), "192.168.237.147")


if __name__ == "__main__":
    unittest.main()
